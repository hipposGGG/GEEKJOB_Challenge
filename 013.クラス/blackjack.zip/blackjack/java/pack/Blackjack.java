/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack.java.pack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author USER
 */


    
      

public class Blackjack {
    public static void main(String[] args){
        Dealer dl = new Dealer(); //プレイヤー二人をインスタンス化
        User us = new User();
        
        System.out.println("【ブラックジャック】の開始");
        System.out.println("");
        
        System.out.println("【ディーラー】の手札"); 
        dl.setCard(dl.deal());           //dlプレイヤーに手札を渡す
        System.out.println(dl.myCards);  //手札の中身
        System.out.println("ディーラーの合計 【　" + dl.open() + "　】");   //手札の合計を算出
        
        System.out.println("");
        
        System.out.println("【ユーザ】の手札"); 
        us.setCard(dl.deal());          //usプレイヤーに手札を渡す
        System.out.println(us.myCards);
        System.out.println("ユーザの合計 【　" + us.open() + "　】");
        
        System.out.println("＝＝＝＝＝＝＝＝＝＝＝＝＝");
        
        //　基準数値に足りてないときの処理
        while(dl.checkSum() == true){
            dl.setCard(dl.hit());
            System.out.print("一枚引いたら【ディーラー】の手札が…"); 
            System.out.println(dl.myCards);
            System.out.println("ディーラーの合計 【　" + dl.open() + "　】");
        }
        System.out.println("");
        
        while(us.checkSum() == true){
            us.setCard(dl.hit());
            System.out.print("一枚引いたら【ユーザ】の手札が…"); 
            System.out.println(us.myCards);
            System.out.println("ユーザの合計 【　" + us.open() + "　】");
        }
        
        
        // 処理結果の発表
        System.out.println("さぁて、結果は…！？");
        System.out.println("");
        if(dl.open() <= 21 && us.open() <= 21){  
            if(dl.open() < us.open() ){
                System.out.println("ユーザのWIN");
            }else if(dl.open() > us.open()){
                System.out.println("ディーラーのWIN");
            }else if(dl.open() == us.open()){
                System.out.println("引き分けです");
            }      
        }else if(dl.open() <= 21 && us.open() > 21){
            System.out.println("ユーザ、バーストのためディーラーのWIN");
        }else if(dl.open() > 21 && us.open() <= 21){
            System.out.println("ディーラー、バーストのためユーザのWIN");
        }else{
            System.out.println("どちらもバーストのためユーザのWIN");
        }
        
    }
}


//1〇.山札を作る
//→1-13×4枚の52枚
//そして条件分岐で11～13は10として使うように代入しなおす
//2,〇山札をシャッフル、ランダムにする。
//→乱数Math.Random関数で1-13を交互に出す。
//3,ランダムの山札中から手札を受け取る
//→hit1枚とDeal2枚を渡す
//4,①受け取った二枚のカードを足し算して合計値を出す
//→UserとDealer別々に加算演算したものの結果を出力
//5,②条件分岐でその合計値が基準値未満(15点)だとfalse

//6,trueだと何もせずfalseの場合はもう一枚追加する
//→追加時に条件分岐で21より上になった際はBLUSTで敗者扱いに遷移
//7,もう一枚追加の処理はhitを使う、
//呼び出しただけでは何もしない

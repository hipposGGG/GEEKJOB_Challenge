/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack.java.pack;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author USER
 */
public class Dealer extends Human{
    
    ArrayList<Integer> cards = new ArrayList<>();
    public Dealer(){
        for(int j=0; j <= 3; j++){
            for(int i = 1; i <= 13;i++) {//トランプ13枚分のfor文
                if( i > 10){  //11以上の数字は10に変換
                    cards.add(10);
                }else{
                    cards.add(i);
                }
            }
        }
        this.myCards = new ArrayList<Integer>();
    }
    public ArrayList<Integer> deal(){
        Random rand = new Random();
        ArrayList<Integer> handList = new ArrayList<>(); //handListに2枚を追加する
        
        Integer hand1 = rand.nextInt(cards.size());
        handList.add(cards.get(hand1));//手札に一枚目を追加
        cards.remove(hand1);//山札からdeal一枚目を抜く
        
        Integer hand2 = rand.nextInt(this.cards.size());
        handList.add(cards.get(hand2));//手札に二枚目を追加
        cards.remove(hand2);//山札からdeal二枚目を抜く
        
        
        return handList;
    }
    public ArrayList<Integer> hit(){
        Random rand = new Random();
        ArrayList<Integer> hitList = new ArrayList<>();
        
        Integer hit1 = rand.nextInt(cards.size());        
        hitList.add(cards.get(hit1));//手札に一枚目を追加
        cards.remove(hit1);//山札からhit一枚目を抜く
        
        return hitList;
    }
    
    
   
    public int open(){ //手札内であるmyCardの合計値 
        int sum = 0;
        for(int i = 0; i < this.myCards.size(); i++){
            sum += this.myCards.get(i);
        }
        return sum;
    }
    
    
    
    public void setCard(ArrayList<Integer> hand){//myCardsにカード情報を渡す
       for(int i = 0; i < hand.size(); i++)
           this.myCards.add(hand.get(i));
    }
    
  
    public boolean checkSum(){ //18より少ないとtrueを返す
        int sum = 0;
        for(int i = 0; i < this.myCards.size(); i++){
            sum += this.myCards.get(i);
        }
        if(sum <= 16)
            return true;
        else
            return false;
    }

    


}


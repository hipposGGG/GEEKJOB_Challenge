/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack.java.pack;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class User extends Human {

    public int open(){ //手札内であるmyCardの合計値
        int sum = 0;
        for(int i = 0; i < this.myCards.size(); i++)
            sum += this.myCards.get(i);
        
        return sum;
    }
    
    public void setCard(ArrayList<Integer> hand){//myCardsにカード情報を渡す
       for(int i = 0; i < hand.size(); i++)
           this.myCards.add(hand.get(i));
    }
    
    public boolean checkSum(){ //18より少ないとtrueを返す
        int sum = 0;
        for(int i = 0; i < this.myCards.size(); i++){
            sum += this.myCards.get(i);
        }
        if(sum <= 18)
            return true;
        else
            return false;
    }

}

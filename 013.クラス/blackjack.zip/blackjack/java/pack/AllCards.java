/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack.java.pack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author USER
 */
public class AllCards {
    public static void main(String[] args){
        List<Integer> cardList;
        cardList = new ArrayList<>();
        for(int j = 0; j <=3; j++){  //4通りのfor文
            for(int i = 1; i <= 13;i++) {  //トランプ13枚分のfor文
                cardList.add(i);   //cardList内に合計52枚分が格納
                //System.out.println(i);
                Collections.shuffle(cardList);//カードをシャッフル
                int result = cardList.get(0);//0番地に格納
                
            }
        }        
    }
}
class all{
    
     
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack.java.pack;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
abstract public class Human  extends Blackjack{
    
    abstract public int open();        
    abstract public void setCard(ArrayList<Integer> myCards);
    abstract public boolean checkSum();
    ArrayList<Integer> myCards = new ArrayList<>(); 
    public static void main(String[] args){
        
    }
}
